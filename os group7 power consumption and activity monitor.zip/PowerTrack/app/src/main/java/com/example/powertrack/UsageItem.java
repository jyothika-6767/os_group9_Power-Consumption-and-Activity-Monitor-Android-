package com.example.powertrack;

public class UsageItem {
    public final String packageName;
    public final String appName;
    public final long foregroundMs;

    public UsageItem(String packageName, String appName, long foregroundMs) {
        this.packageName = packageName;
        this.appName = appName;
        this.foregroundMs = foregroundMs;
    }
}
