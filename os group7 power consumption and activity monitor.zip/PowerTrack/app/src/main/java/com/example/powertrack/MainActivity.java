package com.example.powertrack;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout content;
    private String currentPage = "Dashboard";
    private DatabaseHelper database;

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        database = new DatabaseHelper(this);
        scheduleMonitor();
        showPage("Dashboard");
    }

    private void scheduleMonitor() {
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(
                PowerTrackWorker.class, 15, TimeUnit.MINUTES).build();
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "powertrack_periodic_monitor", ExistingPeriodicWorkPolicy.KEEP, request);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(5), 0, dp(5));
        return t;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private void addCard(String title, String body) {
        LinearLayout card = vertical();
        card.setPadding(dp(16), dp(12), dp(16), dp(12));
        card.setBackgroundColor(Color.rgb(245, 248, 252));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(12));
        content.addView(card, lp);
        card.addView(text(title, 17, Color.rgb(20, 55, 90), true));
        card.addView(text(body, 14, Color.rgb(45, 55, 65), false));
    }

    private Button button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private void showPage(String page) {
        currentPage = page;
        LinearLayout root = vertical();
        root.setBackgroundColor(Color.WHITE);

        LinearLayout header = vertical();
        header.setPadding(dp(18), dp(18), dp(18), dp(10));
        header.setBackgroundColor(Color.rgb(16, 48, 80));
        header.addView(text("PowerTrack", 24, Color.WHITE, true));
        header.addView(text("Power Consumption & Activity Monitor", 13, Color.rgb(220,235,248), false));
        root.addView(header);

        LinearLayout nav = new LinearLayout(this);
        nav.setPadding(dp(4), dp(4), dp(4), dp(4));
        nav.setBackgroundColor(Color.rgb(232, 239, 247));
        String[] pages = {"Dashboard", "Apps", "History", "Settings"};
        for (String p : pages) {
            Button b = new Button(this);
            b.setText(p); b.setTextSize(11); b.setAllCaps(false);
            b.setPadding(dp(2), 0, dp(2), 0);
            b.setOnClickListener(v -> showPage(p));
            nav.addView(b, new LinearLayout.LayoutParams(0, dp(48), 1));
        }
        root.addView(nav);

        ScrollView scroll = new ScrollView(this);
        content = vertical();
        content.setPadding(dp(16), dp(16), dp(16), dp(24));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
        if ("Dashboard".equals(page)) renderDashboard();
        else if ("Apps".equals(page)) renderApps();
        else if ("History".equals(page)) renderHistory();
        else renderSettings();
    }

    private void renderDashboard() {
        MonitorData.BatteryReading r = MonitorData.readBattery(this);
        String level = r.level < 0 ? "Not reported" : r.level + "%";
        addCard("Current battery", level + "\nStatus: " + r.status
                + "\nTemperature: " + (r.temperatureC < 0 ? "N/A" : r.temperatureC + " °C")
                + "\nVoltage: " + (r.voltageMv < 0 ? "N/A" : r.voltageMv + " mV")
                + "\nCurrent: " + (r.currentMa < 0 ? "Not supported" : r.currentMa + " mA"));
        addCard("Monitoring", "Background collection is scheduled approximately every 15 minutes. Android may delay background work to save power.");
        addCard("Historical records", "Saved readings: " + database.getSnapshotCount());
        addCard("Application activity", MonitorData.hasUsageAccess(this)
                ? "Usage Access is enabled. Open Apps to review foreground time."
                : "Usage Access is not enabled. Grant it in Settings to identify application activity.");
        content.addView(button("Refresh battery and app activity", () -> {
            MonitorData.collectAndSave(this);
            Toast.makeText(this, "Reading saved to history", Toast.LENGTH_SHORT).show();
            showPage("Dashboard");
        }));
        content.addView(button("Save reading now", () -> {
            MonitorData.collectAndSave(this);
            Toast.makeText(this, "Reading saved", Toast.LENGTH_SHORT).show();
            showPage("Dashboard");
        }));
        content.addView(text("Last screen refresh: " +
                new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()),
                12, Color.GRAY, false));
    }

    private void renderApps() {
        boolean granted = MonitorData.hasUsageAccess(this);
        addCard("Usage Access", granted
                ? "Permission granted. App foreground time can be read."
                : "Permission required. Tap the button below, find PowerTrack, and enable “Permit usage access”.");
        if (!granted) {
            content.addView(button("Grant Usage Access", () -> MonitorData.openUsageSettings(this)));
        }
        content.addView(button("Refresh application usage", () -> showPage("Apps")));
        if (granted) {
            List<UsageItem> items = MonitorData.readAppUsage(this, 24L * 60L * 60L * 1000L);
            if (items.isEmpty()) addCard("No activity data", "Use a few apps, then return and refresh. Some devices may take time to populate usage statistics.");
            else {
                int count = Math.min(items.size(), 20);
                for (int i = 0; i < count; i++) {
                    UsageItem item = items.get(i);
                    long mins = item.foregroundMs / 60000;
                    String impact = mins >= 60 ? "High activity" : (mins >= 20 ? "Moderate activity" : "Lower activity");
                    addCard((i + 1) + ". " + item.appName,
                            "Foreground time in the last 24 hours: " + MonitorData.formatDuration(item.foregroundMs)
                                    + "\nActivity category: " + impact
                                    + "\nPackage: " + item.packageName
                                    + "\nPower impact: activity-based estimate, not measured battery drain.");
                }
            }
        }
        addCard("How to interpret this", "Foreground time indicates how long an app was visible and active. It does not prove that the app used a specific amount of battery. Android does not expose exact per-app battery attribution to ordinary third-party apps.");
    }

    private void renderHistory() {
        addCard("Monitoring history", "Newest readings appear first. Records are stored locally on this device.");
        addCard("Battery readings", database.getHistoryText(100));
        addCard("Recorded application activity", database.getRecentUsageText(20));
        content.addView(button("Save a reading now", () -> {
            MonitorData.collectAndSave(this);
            Toast.makeText(this, "Reading saved", Toast.LENGTH_SHORT).show();
            showPage("History");
        }));
        content.addView(button("Clear all history", () -> {
            database.clearAll();
            Toast.makeText(this, "Local history cleared", Toast.LENGTH_SHORT).show();
            showPage("History");
        }));
    }

    private void renderSettings() {
        addCard("Usage Access", MonitorData.hasUsageAccess(this)
                ? "Enabled" : "Not enabled. Required for app foreground activity monitoring.");
        content.addView(button("Open Usage Access settings", () -> MonitorData.openUsageSettings(this)));
        addCard("Background monitoring", "PowerTrack uses WorkManager to request a periodic sample every 15 minutes. Android controls the exact execution time; it is not a real-time guarantee.");
        addCard("Data and privacy", "Monitoring records are stored in the app's private local SQLite database. This starter project does not upload your usage or battery data to a server.");
        addCard("Measurement notes", "Battery percentage, temperature, voltage and (when supported) current are device readings. App activity is read from UsageStatsManager. Per-app power impact is an estimate, not exact battery attribution.");
        content.addView(button("Save reading now", () -> {
            MonitorData.collectAndSave(this);
            Toast.makeText(this, "Reading saved", Toast.LENGTH_SHORT).show();
            showPage("Settings");
        }));
    }

    @Override protected void onResume() {
        super.onResume();
        if (content != null && "Apps".equals(currentPage)) showPage("Apps");
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (database != null) database.close();
    }
}
