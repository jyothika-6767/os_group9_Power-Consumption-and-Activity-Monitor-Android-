package com.example.powertrack;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "powertrack.db";
    private static final int DB_VERSION = 1;

    public DatabaseHelper(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE snapshots (id INTEGER PRIMARY KEY AUTOINCREMENT, time_ms INTEGER, level INTEGER, temp_c INTEGER, voltage_mv INTEGER, current_ma INTEGER, status TEXT)");
        db.execSQL("CREATE TABLE app_usage (id INTEGER PRIMARY KEY AUTOINCREMENT, snapshot_id INTEGER, package_name TEXT, app_name TEXT, foreground_ms INTEGER)");
        db.execSQL("CREATE INDEX idx_snapshots_time ON snapshots(time_ms)");
        db.execSQL("CREATE INDEX idx_usage_snapshot ON app_usage(snapshot_id)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

    public long insertSnapshot(int level, int temp, int voltage, int current, String status, long time) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("time_ms", time); v.put("level", level); v.put("temp_c", temp);
        v.put("voltage_mv", voltage); v.put("current_ma", current); v.put("status", status);
        return db.insert("snapshots", null, v);
    }

    public void insertUsage(long snapshotId, List<UsageItem> items) {
        if (snapshotId < 0) return;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            for (UsageItem item : items) {
                ContentValues v = new ContentValues();
                v.put("snapshot_id", snapshotId);
                v.put("package_name", item.packageName);
                v.put("app_name", item.appName);
                v.put("foreground_ms", item.foregroundMs);
                db.insert("app_usage", null, v);
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public String getHistoryText(int limit) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT time_ms, level, temp_c, voltage_mv, current_ma, status FROM snapshots ORDER BY time_ms DESC LIMIT ?",
                new String[]{String.valueOf(limit)});
        StringBuilder out = new StringBuilder();
        SimpleDateFormat fmt = new SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault());
        try {
            while (c.moveToNext()) {
                long time = c.getLong(0);
                out.append(fmt.format(new Date(time))).append("  •  ");
                out.append(c.getInt(1) < 0 ? "Battery N/A" : c.getInt(1) + "%");
                out.append("  •  ").append(c.getString(5));
                if (c.getInt(2) >= 0) out.append("  •  ").append(c.getInt(2)).append("°C");
                if (c.getInt(3) >= 0) out.append("  •  ").append(c.getInt(3)).append(" mV");
                if (c.getInt(4) >= 0) out.append("  •  ").append(c.getInt(4)).append(" mA");
                out.append("\n\n");
            }
        } finally { c.close(); }
        if (out.length() == 0) return "No history yet. Tap “Save reading” or wait for the background monitor.";
        return out.toString();
    }

    public String getRecentUsageText(int limit) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT app_name, package_name, MAX(foreground_ms) AS usage FROM app_usage GROUP BY package_name ORDER BY usage DESC LIMIT ?",
                new String[]{String.valueOf(limit)});
        StringBuilder out = new StringBuilder();
        try {
            while (c.moveToNext()) {
                out.append("• ").append(c.getString(0)).append("\n  ")
                   .append(MonitorData.formatDuration(c.getLong(2))).append(" foreground in a recorded 24-hour window\n\n");
            }
        } finally { c.close(); }
        return out.length() == 0 ? "No application usage records yet. Grant Usage Access and refresh." : out.toString();
    }

    public int getSnapshotCount() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM snapshots", null);
        try { return c.moveToFirst() ? c.getInt(0) : 0; } finally { c.close(); }
    }

    public void clearAll() {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("app_usage", null, null);
        db.delete("snapshots", null, null);
    }
}
