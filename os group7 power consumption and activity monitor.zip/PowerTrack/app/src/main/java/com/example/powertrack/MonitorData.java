package com.example.powertrack;

import android.app.AppOpsManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;
import android.net.Uri;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class MonitorData {
    public static class BatteryReading {
        public int level = -1;
        public int temperatureC = -1;
        public int voltageMv = -1;
        public int currentMa = -1;
        public String status = "Unknown";
    }

    public static BatteryReading readBattery(Context context) {
        BatteryReading r = new BatteryReading();
        Intent battery = context.registerReceiver(null,
                new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery != null) {
            int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            if (level >= 0 && scale > 0) r.level = Math.round(level * 100f / scale);
            int temp = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
            if (temp >= 0) r.temperatureC = temp / 10;
            int voltage = battery.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
            if (voltage >= 0) r.voltageMv = voltage;
            int status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            if (status == BatteryManager.BATTERY_STATUS_CHARGING) r.status = "Charging";
            else if (status == BatteryManager.BATTERY_STATUS_FULL) r.status = "Full";
            else if (status == BatteryManager.BATTERY_STATUS_DISCHARGING) r.status = "Discharging";
            else if (status == BatteryManager.BATTERY_STATUS_NOT_CHARGING) r.status = "Not charging";
            else r.status = "Unknown";
        }

        BatteryManager bm = (BatteryManager) context.getSystemService(Context.BATTERY_SERVICE);
        if (bm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            int microAmps = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
            if (microAmps != Integer.MIN_VALUE && microAmps != 0) {
                r.currentMa = Math.abs(microAmps) / 1000;
            }
        }
        return r;
    }

    public static boolean hasUsageAccess(Context context) {
        AppOpsManager appOps = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
        if (appOps == null) return false;
        int mode;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            mode = appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(), context.getPackageName());
        } else {
            mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(), context.getPackageName());
        }
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    public static List<UsageItem> readAppUsage(Context context, long lookbackMs) {
        List<UsageItem> result = new ArrayList<>();
        if (!hasUsageAccess(context)) return result;

        UsageStatsManager manager = (UsageStatsManager) context.getSystemService(Context.USAGE_STATS_SERVICE);
        if (manager == null) return result;

        long end = System.currentTimeMillis();
        long start = end - lookbackMs;
        // queryUsageStats is available on the project's full API 26+ range.
        // Aggregate entries ourselves rather than relying on newer convenience APIs.
        List<UsageStats> stats = manager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end);
        if (stats == null) return result;

        java.util.Map<String, Long> totals = new java.util.HashMap<>();
        for (UsageStats item : stats) {
            String pkg = item.getPackageName();
            if (pkg == null || pkg.equals(context.getPackageName())) continue;
            long previous = totals.containsKey(pkg) ? totals.get(pkg) : 0L;
            totals.put(pkg, previous + item.getTotalTimeInForeground());
        }

        PackageManager pm = context.getPackageManager();
        for (Map.Entry<String, Long> entry : totals.entrySet()) {
            String pkg = entry.getKey();
            long time = entry.getValue();
            if (time <= 0) continue;
            String label = pkg;
            try {
                ApplicationInfo info = pm.getApplicationInfo(pkg, 0);
                label = pm.getApplicationLabel(info).toString();
            } catch (PackageManager.NameNotFoundException ignored) { }
            result.add(new UsageItem(pkg, label, time));
        }
        Collections.sort(result, new Comparator<UsageItem>() {
            @Override public int compare(UsageItem a, UsageItem b) {
                return Long.compare(b.foregroundMs, a.foregroundMs);
            }
        });
        return result;
    }

    public static void collectAndSave(Context context) {
        BatteryReading r = readBattery(context);
        DatabaseHelper db = new DatabaseHelper(context);
        long snapshotId = db.insertSnapshot(r.level, r.temperatureC, r.voltageMv,
                r.currentMa, r.status, System.currentTimeMillis());
        List<UsageItem> usage = readAppUsage(context, 24L * 60L * 60L * 1000L);
        db.insertUsage(snapshotId, usage);
        db.close();
    }

    public static void openUsageSettings(Context context) {
        Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
        intent.setData(Uri.parse("package:" + context.getPackageName()));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    public static String formatDuration(long ms) {
        long minutes = ms / 60000;
        long hours = minutes / 60;
        minutes %= 60;
        if (hours > 0) return hours + "h " + minutes + "m";
        return minutes + "m";
    }
}
