# PowerTrack – Android Power Consumption and Activity Monitor

A beginner-friendly native Android project written in Java. It reads device battery information, reads application foreground usage after the user grants Usage Access, stores snapshots locally in SQLite, and schedules periodic background sampling with WorkManager.

## Features

- Current battery percentage and charging state
- Battery temperature and voltage where the device reports them
- Battery current where the device supports `BATTERY_PROPERTY_CURRENT_NOW`
- Application foreground usage for the last 24 hours using `UsageStatsManager`
- Local historical battery snapshots and app-usage records
- Periodic background sampling requested every 15 minutes through WorkManager
- Dashboard, Apps, History, and Settings screens
- Clear local history

## Important Android limitation

PowerTrack does **not** claim exact per-app battery consumption. Ordinary third-party applications cannot freely access complete system-level battery attribution for every other app. This project reports measured device-level battery properties and separately reports app foreground time. Its high/moderate/lower activity labels are activity-based indicators, not measured energy use.

WorkManager periodic work has a minimum interval of 15 minutes, and Android may delay execution due to Doze, battery optimization, or system scheduling. A manual “Save reading now” action is included for reliable demonstrations.

## Requirements

- Android Studio (current stable release recommended)
- Android SDK Platform 35 installed
- JDK 17 (normally bundled with Android Studio)
- Android phone running Android 8.0/API 26 or later, or an Android emulator

## Open and run

1. Extract `PowerTrack.zip`.
2. Start Android Studio.
3. Choose **Open** and select the extracted `PowerTrack` folder (the folder containing `settings.gradle`).
4. Allow Gradle sync to finish. The first sync needs internet access to download Android Gradle Plugin and WorkManager.
5. In **Tools > SDK Manager**, install Android SDK Platform 35 and Build Tools if Android Studio requests them.
6. Connect an Android phone with USB debugging enabled, or start an emulator (API 26+).
7. Press **Run**.

This project intentionally omits a Gradle wrapper JAR. Opening the project in Android Studio is the recommended beginner workflow; Android Studio will use/configure its Gradle installation. If you want command-line builds, generate a wrapper from Android Studio's terminal with `gradle wrapper` after Gradle is available.

## Grant Usage Access

1. Open PowerTrack.
2. Select **Apps**.
3. Tap **Grant Usage Access**.
4. Android opens Usage Access settings.
5. Find **PowerTrack** and enable **Permit usage access**.
6. Return to PowerTrack.

Usage Access is a special user-granted setting, not a normal runtime permission dialog.

## Build an APK

1. In Android Studio, select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
2. Wait for the build to finish.
3. Click **locate** in the build notification.
4. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer the APK to a phone and install it. For sharing outside your own test devices, create a signed APK using **Build > Generate Signed Bundle / APK**.

## Demonstration procedure – real phone

1. Install and open PowerTrack.
2. Grant Usage Access.
3. Open YouTube, Chrome, Maps, or another app and use it for 2–5 minutes.
4. Return to PowerTrack > Apps and tap **Refresh application usage**. Confirm that the app appears with foreground time.
5. Open Dashboard and note battery percentage, temperature, voltage and charging state.
6. Tap **Save reading now**. Open History and confirm the timestamped record appears.
7. Use the phone for a while, then save another reading and compare the battery level.
8. Leave the app installed for 15–30 minutes to allow WorkManager to run when Android schedules it. Explain that periodic work is approximate, not exact real-time sampling.

## Demonstration procedure – emulator

1. Create an emulator with API 26 or later and launch the app.
2. Open Apps > Grant Usage Access and enable PowerTrack.
3. Launch Chrome or another installed app in the emulator, use it, then return to PowerTrack and refresh.
4. Save a reading and verify it in History.
5. To simulate battery changes, open the emulator's **Extended controls > Battery** and adjust the battery level or charging state (available controls depend on emulator version).
6. Refresh the dashboard and demonstrate the changed device-level reading.

Some emulator images do not provide temperature/current readings or realistic app usage. Show “N/A” when the emulator does not expose a property; do not present fabricated values.

## Project structure

```text
PowerTrack/
├── settings.gradle
├── build.gradle
├── gradle.properties
├── README.md
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        └── java/com/example/powertrack/
            ├── MainActivity.java
            ├── MonitorData.java
            ├── DatabaseHelper.java
            ├── PowerTrackWorker.java
            └── UsageItem.java
```

## Troubleshooting

- **Usage list empty:** Ensure Usage Access is enabled for PowerTrack, use other apps for a few minutes, then refresh.
- **Battery current says Not supported:** The device does not expose a usable current reading to this app.
- **History has no automatic records:** Tap Save reading now to verify the database. WorkManager can be delayed by Android; wait and check again.
- **Gradle sync fails:** Check internet access, JDK 17, and Android SDK Platform 35.
- **Emulator battery does not change:** Use Extended Controls > Battery, or demonstrate on a physical phone.

## Academic demonstration explanation

PowerTrack combines `BatteryManager` for device-level battery properties, `UsageStatsManager` for foreground application activity, SQLite for local historical persistence, and WorkManager for periodic background collection. The design separates measured device readings from activity-based app impact estimates to avoid claiming inaccessible per-app energy measurements.
